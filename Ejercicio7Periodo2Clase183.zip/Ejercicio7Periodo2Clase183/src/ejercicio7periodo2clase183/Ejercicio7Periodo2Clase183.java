/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio7periodo2clase183;

/**
 *
 * @author jenni
 */
public class Ejercicio7Periodo2Clase183 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    for (int n = 1; n <=10; n++) {
        int f = 1;
        for (int i = 2; i<=n; i++) {
            f *=i; //equivalente a f = f * 1
        }
        System.out.print("El factorial de " + n);
        System.out.println(" es: " + f);
    }
    }
    
}
