/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2periodo2clase6;

/**
 *
 * @author jenni
 */
public class Ejercicio2Periodo2Clase6 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    String str = "dos";
    switch(str)
    {
        case "uno":
            System.out.println("uno");
            break;
            case "dos":
            System.out.println("dos");
            break;
            case "tres":
            System.out.println("tres");
            break;
            default:
                System.out.println("no coincide");
    }
                
            
    }
    
}
