/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3periodo3;
import java.util.Scanner;
/**
 *
 * @author jenni
 */
public class Ejercicio3Periodo3 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Scanner objetoNum = new Scanner (System.in);
    
    int valinicial, valfinal;
    
    valinicial=8;
    System.out.println("Multiplos de 8 hasta 500");
    
    while(valinicial<=500)
        
    {
        System.out.print(valinicial+",");
        valinicial=valinicial+8;
    }
    }
    
}
