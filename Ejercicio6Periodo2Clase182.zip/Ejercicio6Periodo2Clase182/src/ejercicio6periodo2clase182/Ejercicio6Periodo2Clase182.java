/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio6periodo2clase182;

/**
 *
 * @author jenni
 */
public class Ejercicio6Periodo2Clase182 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    for (char c='a'; c<='z'; c++) {
        System.out.println("El caracter " + (int)c + "es: " + c);
    }
    }
    
}
