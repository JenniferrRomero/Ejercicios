/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio3periodo1;
import java.util.Scanner;
/**
 *
 * @author jenni
 */
public class Ejercicio3Periodo1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    Scanner Entrada = new Scanner (System.in);
    int reglas;
    double nota;
    System.out.println ("Usted cumple las reglas de la universidad: ");
    System.out. println("'Ingrese un numero: \n 1. Siempre \n 2. Aveces \n 3.Nunca");
    reglas = Entrada.nextInt();
    System.out.println("Que nota obtuvo en el laboratorio: ");
    nota = Entrada.nextDouble();
    if (reglas == 1){
        if (nota >= 8 & nota <= 10){
            nota = 10;
        } else {
            System.out.println("Nota invalida");          
        }
    } else if (reglas == 2){
        if (nota < 6){
            nota = nota + 0.5;
        } else if (nota >= 6 & nota < 8){
            nota = nota + 0.7;
        } else { 
            System.out.println("Nota valida");
        }
    } else { 
        System.out.println("Usted debe cumplir las reglas");
    }
    System.out.println("La nueva etapa es: " + nota);
}
}
